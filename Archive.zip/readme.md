## Special Notes for 003-user-alerts-01


- Make sure to prepend `/tmp/` to any file paths inside the `xmlhttprequest` call. Currently chane the paths for `contentFile` and `syncFile` on lines 475, 476.
